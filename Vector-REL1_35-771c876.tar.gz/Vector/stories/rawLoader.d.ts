declare module "!!raw-loader!*" {
	const src: string;
	export default src;
}
